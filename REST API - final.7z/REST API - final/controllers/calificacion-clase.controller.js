


// SOLO PUEDEN ACCEDER LOS AuthorizationAlumno
exports.calificarClase = async function(req,res){

    const { userId } = req;

    // Si no existe el userId, retornamos error, pues solamente pueden ver las clases, la gente logueada
    if(!userId){
        return res.status(401).send({err: 'No autorizado'});
    }

    const userFound = await UserService.findById(userId);

     // Si no encontramos un usuario en la base de datos devolvemos un 400 (Bad request)
    if(!userFound){
        return res.status(400).send({err: 'Bad Request'});
    }

    const { idClase } = req.params;

    const claseFound = await ClaseService.findById(idClase);

   // Si la clase no existe, retornamos badRequest
    if(!claseFound){
        return res.status(400).send({err: 'Bad Request'});
    }

    // Revisamos que el usuario, tenga una contratacion de la clase

    const checkContratacion =  await ContratacionService.findByAlumnoYClase(idClase, userId);

    if(!checkContratacion){
        return res.status(400).send({err: 'No puedes calificar una clase que no contrataste'});
    }

    //Revisamos que ya no haya calificado antes. si ya existe, devolvemos error
    const checkCalificacion = await CalificacionService.findCalificacion(idClase, userId);
    if(checkCalificacion){
        return res.status(400).send({err: 'Bad Request'});
    }

    const { calificacion } = req.body;
    // Si no se envió la calificacion en el body, lanzamos error
    if(!calificacion){
        return res.status(400).send({err: 'Bad Request'});
    }

    const nuevaCalificacion = await CalificacionService.createCalificacion(idClase, userId, calificacion);


    return res.status(200).send(nuevaCalificacion)
}


// SOLO PUEDEN ACCEDER LOS AuthorizationAlumno
exports.editarCalificacionClase = async function(req,res){

    const { userId } = req;

    // Si no existe el userId, retornamos error, pues solamente pueden ver las clases, la gente logueada
    if(!userId){
        return res.status(401).send({err: 'No autorizado'});
    }

    const userFound = await UserService.findById(userId);

     // Si no encontramos un usuario en la base de datos devolvemos un 400 (Bad request)
    if(!userFound){
        return res.status(400).send({err: 'Bad Request'});
    }

    const { idClase } = req.params;

    const claseFound = await ClaseService.findById(idClase);

   // Si la clase no existe, retornamos badRequest
    if(!claseFound){
        return res.status(400).send({err: 'Bad Request'});
    }

    //Revisamos que ya  haya calificado antes
    const checkCalificacion = await CalificacionService.findCalificacion(idClase, userId);
    if(!checkCalificacion){
        return res.status(400).send({err: 'Bad Request, no puedes editar una calificacion, si nunca calificaste!!!'});
    }

    const { calificacion } = req.body;
    // Si no se envió la calificacion en el body, lanzamos error
    if(!calificacion){
        return res.status(400).send({err: 'Bad Request'});
    }

    const editCalificacion = await CalificacionService.editarCalificacion(checkCalificacion.id, calificacion);


    return res.status(200).send(editCalificacion)
    
}
