

// forma 1 (OBJETOS DE TIPO ELEMENTAL)
/** 
 * 
 *  idClase: stirng
 *  idUsuarioAlumno: string
 *  status: string
 * 
 */


//forma 2 (RELACIONES)
/** 
 * 
 *  clase: Clase
 *  idUsuarioAlumno: Usuario
 *  status: string
 * 
 */


// SOLO PUEDEN ACCEDER LOS AuthorizationProfesor.


exports.getContratacionesByClase = async function(req,res){

    const { isProfesor, userId } = req;

    // Si isProfesor es false, devolvemos un 401
    if(!isProfesor){
        return res.status(401).send({err: 'No autorizado'});
    }

    const userFound = await UserService.findById(userId);

     // Si no encontramos un usuario en la base de datos devolvemos un 400 (Bad request)
    if(!userFound){
        return res.status(400).send({err: 'Bad Request'});
    }


    const { idClase } = req.params;

    const claseFound = await ClaseService.findById(idClase);

    // Si por algūn motivo, la clase no existe, retornamos error
    if(!claseFound){
        return res.status(400).send({err: 'Bad Request'});
    }

    if(claseFound.idProfesor !== userId){
        return res.status(401).send({err: 'No sos el profesor de esta clase, por ende, no podes ver las contrataciones'});
    }

    const allContrataciones = await ContratacionService.getAllContratacionesByIdClase(idClase);


    return res.status(200).send(allContrataciones);

}

// SOLO PUEDEN ACCEDER LOS AuthorizationProfesor
exports.aceptarContratacion = async function (req, res) {

    const { isProfesor, userId } = req;

    // Si isProfesor es false, devolvemos un 401
    if(!isProfesor){
        return res.status(401).send({err: 'No autorizado'});
    }

    const userFound = await UserService.findById(userId);

     // Si no encontramos un usuario en la base de datos devolvemos un 400 (Bad request)
    if(!userFound){
        return res.status(400).send({err: 'Bad Request'});
    }

    // Recuperamos idContratacion de los parámetros
    const { idContratacion } = req.body;

    // Si no existe, devolvemos 400 (Bad request)
    if(!idContratacion){
        return res.status(400).send({err: 'Bad Request'});
    }


    // Buscamos la contratacion en la base de datos
    const contratacionFound = await ContratacionService.findById(id);

    // Si no existe, devolvemos error
    if(!contratacionFound){
        return res.status(400).send({err: 'Bad Request'});
    }

    const { idClase } = contratacionFound;

    const claseFound = await ClaseService.findById(idClase);

    // Si por algūn motivo, la clase se eliminò o pasó algo, retornamos error, 
    if(!claseFound){
        return res.status(400).send({err: 'Bad Request'});
    }

    if(claseFound.idProfesor !== userId){
        return res.status(401).send({err: 'No sos el profesor de esta clase, por ende no podes aprobar la contratacion'});
    }

    const updateContratacion = await ContratacionService.updateContratacion(idContratacion, 'Aceptada')

    return res.status(200).send(updateContratacion);

}


/** 
 * 
 * 
 *  CONTRATACION 
 * {
 *     idClase
 *     idUsuario
 *     status : 'Pendiente' | 'Rechazado' | 'Aceptado' | 'Cancelado'
 * }
 * 
 * 
 */
//POST /contrataciones/jaksdkjaskldljkejlkdsa/cancelar

// SOLO PUEDEN ACCEDER LOS Authorization
exports.cancelarContratacion = async function (req, res) {

    const { userId } = req;


    const userFound = await UserService.findById(userId);

     // Si no esta en la base de datos
    if(!userFound){
        return res.status(400).send({err: 'Bad Request'});
    }

    // Recuperamos idContratacion de los parámetros
    const { idContratacion } = req.body;

    // Si no existe, devolvemos 400 (Bad request)
    if(!idContratacion){
        return res.status(400).send({err: 'Bad Request'});
    }

    // Buscamos la contratacion en la base de datos
    const contratacionFound = await ContratacionService.findById(id);

    // Si no existe, devolvemos error
    if(!contratacionFound){
        return res.status(400).send({err: 'Bad Request'});
    }

    // La cancelacion de la contratacion, la solicitó el alumno usuario, por lo tanto, puede cancelarla
    if(contratacionFound.idUser === userId){

        const updateContratacion = await ContratacionService.cancelarContratacion(idContratacion, 'Cancelada')

        return res.status(200).send(updateContratacion);

    }
    else{
        // Veamos si es profesor de esa clase

        const { idClase } = contratacionFound;

        const claseFound = await ClaseService.findById(idClase);
    
        // Si por algūn motivo, la clase se eliminò o pasó algo, retornamos error, 
        if(!claseFound){
            return res.status(400).send({err: 'Bad Request'});
        }
    
        if(claseFound.idProfesor !== userId){
            return res.status(401).send({err: 'No sos el profesor de esta clase, por ende no podes Cancelar la contratacion'});
        }
    

    const updateContratacion = await ContratacionService.updateContratacion(idContratacion, 'Cancelada')

    return res.status(200).send(updateContratacion);

    }

}



// SOLO PUEDEN ACCEDER LOS Authorization
exports.finalizarContratacion = async function (req, res) {

    const { userId } = req;


    const userFound = await UserService.findById(userId);

     // Si isProfesor es false, devolvemos un 401
    if(!userFound){
        return res.status(400).send({err: 'Bad Request'});
    }

    // Recuperamos idContratacion de los parámetros
    const { idContratacion } = req.body;

    // Si no existe, devolvemos 400 (Bad request)
    if(!idContratacion){
        return res.status(400).send({err: 'Bad Request'});
    }

    // Buscamos la contratacion en la base de datos
    const contratacionFound = await ContratacionService.findById(id);

    // Si no existe, devolvemos error
    if(!contratacionFound){
        return res.status(400).send({err: 'Bad Request'});
    }

    // La contratacion, la solicitó el usuario, por lo tanto, puede cancelarla
    if(contratacionFound.idUser === userId){

        const updateContratacion = await ContratacionService.updateContratacion(idContratacion, 'Finalizada')

        return res.status(200).send(updateContratacion);

    }
    else{
        // Veamos si es profesor de esa clase

        const { idClase } = contratacionFound;

        const claseFound = await ClaseService.findById(idClase);
    
        // Si por algūn motivo, la clase se eliminò o pasó algo, retornamos error, 
        if(!claseFound){
            return res.status(400).send({err: 'Bad Request'});
        }
    
        if(claseFound.idProfesor !== userId){
            return res.status(401).send({err: 'No sos el profesor de esta clase, por ende no podes Finalizar la contratacion'});
        }
    

    const updateContratacion = await ContratacionService.updateContratacion(idContratacion, 'Finalizada')

    return res.status(200).send(updateContratacion);

    }

}
