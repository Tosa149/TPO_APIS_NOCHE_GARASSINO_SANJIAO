


// SOLO PUEDEN ACCEDER LOS AuthorizationAlumno
exports.comentarClase = async function(req,res){

    const { userId, isAlumno } = req;

    // Si no existe el userId, retornamos error, pues solamente pueden ver las clases, la gente logueada
    if(!userId || !isAlumno){
        return res.status(401).send({err: 'No autorizado, solo alumnos pueden comentar'});
    }

    const userFound = await UserService.findById(userId);

     // Si no encontramos un usuario en la base de datos devolvemos un 400 (Bad request)
    if(!userFound){
        return res.status(400).send({err: 'Bad Request'});
    }

    const { idClase, comentario } = req.body;

    const claseFound = await ClaseService.findById(idClase);

   // Si la clase no existe, retornamos badRequest
    if(!claseFound){
        return res.status(400).send({err: 'Bad Request'});
    }

    // Revisamos que el usuario, tenga una contratacion de la clase

    const checkContratacion =  await ContratacionService.findByAlumnoYClase(idClase, userId);

    if(!checkContratacion){
        return res.status(400).send({err: 'No puedes comentar una clase que no contrataste'});
    }

    const nuevoComentario = {
        idUsuario: userId,
        idClase: idClase,
        comentario
    }

    const nuevoComentarioResponse = await ComentarioClaseService.createComentario(nuevoComentario);


    return res.status(200).send(nuevoComentarioResponse)
}


// SOLO PUEDEN ACCEDER LOS AuthorizationProfesor
exports.rechazarComentario = async function(req,res){

    const { userId, isProfesor } = req;

    // Si no existe el userId, retornamos error, pues solamente pueden ver las clases, la gente logueada
    if(!userId || !isProfesor){
        return res.status(401).send({err: 'No autorizado'});
    }

    const userFound = await UserService.findById(userId);

     // Si no encontramos un usuario en la base de datos devolvemos un 400 (Bad request)
    if(!userFound){
        return res.status(400).send({err: 'Bad Request'});
    }

    const { idComentario, motivo } = req.body;

    const comentarioFound = await ComentarioClaseService.findById(idComentario);

   // Si el comentario no existe, retornamos badRequest
    if(!comentarioFound){
        return res.status(400).send({err: 'Bad Request'});
    }

    //Revisamos que el userId, sea el profesor de la clase que pertenece al comentario
    const checkComentario = await ComentarioClaseService.checkProfesorComentario(idComentario,userId)
    if(!checkComentario){
        return res.status(400).send({err: 'Bad Request, no puedes rechazar un comentario de una clase que no es tuya!!'});
    }

    // Si no se envió el motivo en el body, lanzamos error
    if(!motivo){
        return res.status(400).send({err: 'Bad Request'});
    }

    const rechazarComentario = await ComentarioClaseService.rechazarComentario(idComentario, motivo);


    return res.status(200).send(rechazarComentario)
    
}
