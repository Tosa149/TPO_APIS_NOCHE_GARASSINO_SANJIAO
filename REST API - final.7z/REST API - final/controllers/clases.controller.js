
var ClaseService = require('../services/clases.service');
var UserService = require('../services/user.service');

// SOLO PUEDEN ACCEDER LOS Authorization // LO ESTA LLAMANDO UN ALUMNO
exports.getClases = async function(req,res){

    return res.status(200).send(await ClaseService.getClases())
}



// SOLO PUEDEN ACCEDER LOS Authorization // LO ESTA LLAMANDO UN ALUMNO
exports.getClasesContradasPorAlumno = async function(req,res){

    const { userId } = req;

    // Si no existe el userId, retornamos error, pues solamente pueden ver las clases, la gente logueada
    if(!userId){
        return res.status(401).send({err: 'No autorizado'});
    }

    const userFound = await UserService.getUserById(userId);

     // Si no encontramos un usuario en la base de datos devolvemos un 400 (Bad request)
    if(!userFound){
        return res.status(400).send({err: 'Bad Request'});
    }


    const contratacionesRealizadasPorElAlumno = await ContratacionesService.findByUserId(userId);

    const idClasesContratadas = contratacionesRealizadasPorElAlumno.map((contrtacion) => contrtacion.idClase)

    const clasesContratadasFound = await ClaseService.find({ idClase: idClasesContratadas  });


    clasesContratadasFound.forEach((clase) => {
        const contratacionActual = contratacionesRealizadasPorElAlumno.find(contratacion => contratacion.idClase === clase.id);
            clase.solicitada = true;
            clase.estado = contratacionActual.status;
    })

    return res.status(200).send(clasesFound)
}




// SOLO PUEDEN ACCEDER LOS Authorization
exports.getClaseById = async function(req,res){

    const { userId } = req;

    // Si no existe el userId, retornamos error, pues solamente pueden ver las clases, la gente logueada
    if(!userId){
        return res.status(401).send({err: 'No autorizado'});
    }

    const userFound = await UserService.getUserById(userId);

     // Si no encontramos un usuario en la base de datos devolvemos un 400 (Bad request)
    if(!userFound){
        return res.status(400).send({err: 'Bad Request'});
    }

    const { id } = req.params;

    const claseFound = await ClaseService.findById(id);

   // Si la clase no existe, retornamos badRequest
   if(!claseFound){
        return res.status(400).send({err: 'Bad Request'});
    }

    return res.status(200).send(claseFound)
    
}


// SOLO PUEDEN ACCEDER LOS AuthorizationProfesor
exports.createClase = async function(req,res){

    const { isProfesor, userId } = req;

    // Si isProfesor es false, devolvemos un 401
    if(!isProfesor){
        return res.status(401).send({err: 'No autorizado'});
    }

    const userFound = await UserService.getUserById(userId);

     // Si no encontramos un usuario en la base de datos devolvemos un 400 (Bad request)
    if(!userFound){
        return res.status(400).send({err: 'Bad Request'});
    }

    const { nombre, materia, duracion, frecuencia, costo } = req.body;
    
    //Validamos que todos los parámetros de la clase, sean correctos, sinò, retornamos error
    if(!nombre || !materia || !duracion || !frecuencia || !costo ){
        return res.status(400).send({err: 'bad request'})
    }

    const nuevaClase = {
        nombre,
        materia,
        duracion,
        costo,
        frecuencia,
        profesor: userId,
        publicada: true
    }

    const nuevaClaseResponse = await ClaseService.createClase(nuevaClase);

    return res.status(200).send(await ClaseService.findById(nuevaClaseResponse._id));

    
}

// SOLO PUEDEN ACCEDER LOS AuthorizationProfesor
exports.deleteClase = async function(req,res){

    const { isProfesor, userId } = req;

    // Si isProfesor es false, devolvemos un 401
    if(!isProfesor){
        return res.status(401).send({err: 'No autorizado'});
    }

    const userFound = await UserService.getUserById(userId);

     // Si no encontramos un usuario en la base de datos devolvemos un 400 (Bad request)
    if(!userFound){
        return res.status(400).send({err: 'Bad Request'});
    }

    const { idClase } = req.params;

    const claseFound = await ClaseService.findById(idClase);

    // Si la clase no existe, retornamos badRequest
    if(!claseFound){
        return res.status(400).send({err: 'Bad Request'});
    }

    if(claseFound.profesor._id != userId){
        return res.status(401).send({err: 'No sos el profesor de esta clase, no la podes eliminar'});
    }

    const deleteClaseResponse = await ClaseService.deleteClase(idClase);

    return res.status(200).send(deleteClaseResponse);

    
}

// SOLO PUEDEN ACCEDER LOS AuthorizationProfesor
exports.updateClase = async function(req,res){

    const { isProfesor, userId } = req;

    // Si isProfesor es false, devolvemos un 401
    if(!isProfesor){
        return res.status(401).send({err: 'No autorizado'});
    }

    const { nombre, materia, duracion, frecuencia, costo } = req.body;
        
    //Validamos que todos los parámetros de la clase, sean correctos, sinò, retornamos error
    if(!nombre || !materia || !duracion || !frecuencia || !costo ){
        return res.status(400).send({err: 'bad request, parametros imcompletos'})
    }


    const userFound = await UserService.getUserById(userId);

     // Si no encontramos un usuario en la base de datos devolvemos un 400 (Bad request)
    if(!userFound){
        return res.status(400).send({err: 'Bad Request'});
    }

    const { idClase } = req.params;

    const claseFound = await ClaseService.findById(idClase);

    // Si la clase no existe, retornamos badRequest
    if(!claseFound){
        return res.status(400).send({err: 'Bad Request'});
    }

    console.log(claseFound,userId)
    if(claseFound.profesor._id != userId){
        return res.status(401).send({err: 'No sos el profesor de esta clase, no la podes editarla'});
    }

    const editClase = {
        nombre,
        materia,
        duracion,
        costo,
        frecuencia,
        publicada: true
    }

    

    const editClaseResponse = await ClaseService.editClase(idClase, editClase);

    return res.status(200).send(await ClaseService.findById(idClase));

    
}


// SOLO PUEDEN ACCEDER LOS AuthorizationProfesor
exports.publicarClase = async function(req,res){

    const { isProfesor, userId } = req;

    // Si isProfesor es false, devolvemos un 401
    if(!isProfesor){
        return res.status(401).send({err: 'No autorizado'});
    }

    const userFound = await UserService.getUserById(userId);

     // Si no encontramos un usuario en la base de datos devolvemos un 400 (Bad request)
    if(!userFound){
        return res.status(400).send({err: 'Bad Request'});
    }

    const { idClase } = req.params;

    const claseFound = await ClaseService.findById(idClase);

    // Si la clase no existe, retornamos badRequest
    if(!claseFound){
        return res.status(400).send({err: 'Bad Request'});
    }

    if(claseFound.profesor._id != userId){
        return res.status(401).send({err: 'No sos el profesor de esta clase, no la podes editarla'});
    }

    // Si la clase ya estba publicada, no podemos volver a publicarla. Devolvemos error
    if(claseFound.publicada == true){
        return res.status(400).send({err: 'Bad Request  no podes publicar una clase, ya publicada'});
    }
    
    const editClaseResponse = await ClaseService.publicarClase(idClase);

    return res.status(200).send(editClaseResponse);

}

// SOLO PUEDEN ACCEDER LOS AuthorizationProfesor
exports.despublicarClase = async function(req,res){

    const { isProfesor, userId } = req;

    // Si isProfesor es false, devolvemos un 401
    if(!isProfesor){
        return res.status(401).send({err: 'No autorizado'});
    }

    const userFound = await UserService.getUserById(userId);

     // Si no encontramos un usuario en la base de datos devolvemos un 400 (Bad request)
    if(!userFound){
        return res.status(400).send({err: 'Bad Request'});
    }

    const { idClase } = req.params;

    const claseFound = await ClaseService.findById(idClase);

    // Si la clase no existe, retornamos badRequest
    if(!claseFound){
        return res.status(400).send({err: 'Bad Request'});
    }

    if(claseFound.profesor._id != userId){
        return res.status(401).send({err: 'No sos el profesor de esta clase, no la podes despublicarla'});
    }

    // Si la clase ya estba publicada, no podemos volver a despublicarla. Devolvemos error
    if(claseFound.publicada == false){
        return res.status(400).send({err: 'Bad Request, no podes despublicar una clase, ya despublicada'});

    }
    
    const editClaseResponse = await ClaseService.despublicarClase(idClase);

    return res.status(200).send(editClaseResponse);


    
}
