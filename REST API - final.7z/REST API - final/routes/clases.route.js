var express = require('express');
var router = express.Router()
var ClasesController = require('../controllers/clases.controller');

const authorization = require('../auth/authorization'); //Middleware General Login
const authorizationAlumno = require('../auth/authorizationAlumno'); // Middleware Alumno
const authorizationProfesor = require('../auth/authorizationProfesor'); //Middleware Profesor


//Todas las clases
router.get('', authorization, ClasesController.getClases);

// Clase contratadas por alumno
router.get('/alumno', authorizationAlumno, ClasesController.getClasesContradasPorAlumno);

// Clase by Id
router.get('/:id', authorization, ClasesController.getClaseById);

//Crear Clase
router.post('/',authorizationProfesor, ClasesController.createClase);

//Eliminar Clase
router.delete('/:idClase',authorizationProfesor, ClasesController.deleteClase);

// Update Clase
router.put('/:idClase', authorizationProfesor, ClasesController.updateClase);

// publicar Clase 
router.post('/:idClase/publicar', authorizationProfesor, ClasesController.publicarClase);

// despublicar Clase 
router.post('/:idClase/despublicar', authorizationProfesor, ClasesController.despublicarClase);


// Export the Router
module.exports = router;


