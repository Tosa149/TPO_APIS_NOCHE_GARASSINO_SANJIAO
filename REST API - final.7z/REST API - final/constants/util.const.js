exports.ROL_USER = {
    PROFESOR: 'profesor',
    ALUMNO: 'alumno'
}