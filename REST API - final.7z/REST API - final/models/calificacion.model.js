var mongoose = require('mongoose')
var mongoosePaginate = require('mongoose-paginate')


var calificacionSchema = new mongoose.Schema({
    usuario: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User"
    }, 
    clase: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Clases"
    }, 
    calificacion: Number
})

calificacionSchema.plugin(mongoosePaginate)
const Calificacion = mongoose.model('calificaciones', calificacionSchema)

module.exports = Calificacion;